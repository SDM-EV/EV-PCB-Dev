*PADS-LIBRARY-PART-TYPES-V9*

RRL035P03FRATR RRL035P03FRATR I TRX 7 1 0 0 0
TIMESTAMP 2026.09.05.04.13.14
"Mouser Part Number" 755-RRL035P03FRATR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/ROHM-Semiconductor/RRL035P03FRATR?qs=4v%252BiZTmLVHGxGv7angTM%2FA%3D%3D
"Manufacturer_Name" ROHM Semiconductor
"Manufacturer_Part_Number" RRL035P03FRATR
"Description" Pch -30V -3.5A Power MOSFET  RDS(on) (Max.) :50 ohm  PD:1.0W  SOT-363T (TUMT6)
"Datasheet Link" https://fscdn.rohm.com/en/products/databook/datasheet/discrete/transistor/mosfet/rrl035p03fra-e.pdf
"Geometry.Height" 0.85mm
GATE 1 6 0
RRL035P03FRATR
1 0 U D_1
2 0 U D_2
3 0 U G
4 0 U S
5 0 U D_3
6 0 U D_4

*END*
*REMARK* SamacSys ECAD Model
1319806/1501223/2.50/6/2/MOSFET (P-Channel)
