*PADS-LIBRARY-PART-TYPES-V9*

TLV9064IRUCR QFN40P200X200X40-14N I ANA 7 1 0 0 0
TIMESTAMP 2026.09.08.02.11.23
"Mouser Part Number" 595-TLV9064IRUCR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TLV9064IRUCR?qs=l7cgNqFNU1j19qNA%252Bm74vQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TLV9064IRUCR
"Description" 4 channel, 10-MHz, Low-Noise, RRIO, CMOS Operational Amplifier for Cost-Sensitive Systems
"Datasheet Link" http://www.ti.com/lit/gpn/TLV9064
"Geometry.Height" 0.4mm
GATE 1 14 0
TLV9064IRUCR
1 0 U IN1-
2 0 U IN1+
3 0 U V+
4 0 U IN2+
5 0 U IN2-
6 0 U OUT2
7 0 U OUT3
12 0 U IN4-
11 0 U IN4+
10 0 U V-
9 0 U IN3+
8 0 U IN3-
14 0 U OUT1
13 0 U OUT4

*END*
*REMARK* SamacSys ECAD Model
1871834/1501223/2.50/14/4/Integrated Circuit
